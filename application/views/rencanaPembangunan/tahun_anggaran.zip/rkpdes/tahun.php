
		<?php $id_tahun_anggaran = 'id="id_tahun_anggaran" class="form-control" required';
				echo form_dropdown('id_tahun_anggaran',$tahun_anggaran,'',$id_tahun_anggaran)?> 
		<?php echo form_error('id_tahun_anggaran', '<p class="field_error">','</p>')?>	


