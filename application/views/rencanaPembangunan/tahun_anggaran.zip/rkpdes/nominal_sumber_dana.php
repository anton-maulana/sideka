
<input class="form-control input-md" type="text" name="nominal_sumber_dana" id="nominal_sumber_dana" value="<?= $nominal_sumber_dana ?>" readonly/>
